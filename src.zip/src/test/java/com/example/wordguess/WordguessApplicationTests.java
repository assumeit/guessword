package com.example.wordguess;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WordGuessGameApplicationTests {

	@Test
	void contextLoads() {
	}

}